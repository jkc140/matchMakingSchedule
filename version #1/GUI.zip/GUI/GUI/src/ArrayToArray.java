/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S331461103
 */
public class ArrayToArray {
    public static void main(String[] args) {
    String [][][][] matches = new String[34][5][2][2];
    String [][] Display = new String[matches.length][7];
    int[] matchNum = {2,3,4,5,6};
    int counter = 1;
   
    System.out.println(String.valueOf(matches[0]));
        for (int x = 0; x<(matches.length*2); x++){
            
            for(int z=0;z<1;z++){

                 if ((counter%2)> 0){
                Display [x][1]= "6:00 PM";
                }
                else {
                Display [x][1]= "7:00 PM";  
                }
                counter++;
                
            
                for(int y=0;y< matches[x].length;y++){
                    for (int a=0;a<1;a++){
                        String team = (matches[x][y][z][0]+ " VS. "+matches[x][y][z][1]);
                        Display[x][matchNum[y]]= team;
                    }
                }
            }

    }
    
    }
}
