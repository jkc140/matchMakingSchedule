/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S331461103
 */
public class ArrayToArray {
    public static void main(String[] args) {
    String [][][][] matches = new String[34][5][2][2];
    String [][] Display = new String[matches.length][7];
   
    System.out.println(String.valueOf(matches[0]));
        for (int x = 0; x<(matches.length); x++){
            for(int z=0;z<2;z++){
                //if z=0 then it is 6
                //if z is 1 it is 7
            
                for(int y=0;y< matches[x].length;y++){
                    for (int a=0;a<1;a++){
                        String team1= (matches[x][y][z][0]+ " VS. "+matches[x][y][z][1]);
                    }
                }
            }

    }
    
    }
}
